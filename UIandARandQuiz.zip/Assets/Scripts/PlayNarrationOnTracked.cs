using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

[RequireComponent(typeof(ARTrackedImage))]
public class PlayNarrationOnTracked : MonoBehaviour
{
    private ARTrackedImage trackedImage;
    private AudioSource audioSource;
    private bool hasPlayed = false;

    void Awake()
    {
        trackedImage = GetComponent<ARTrackedImage>();
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (!hasPlayed && trackedImage.trackingState == TrackingState.Tracking)
        {
            // Start the narration
            audioSource.Play();
            hasPlayed = true;
        }
    }
}
